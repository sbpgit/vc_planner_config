sap.ui.define([
  "sap/ui/core/UIComponent",
  "sap/ui/core/HTML"
], function (UIComponent, HTML) {
  "use strict";

  return UIComponent.extend("dependency.probab.rule.Component", {
    metadata: {
      manifest: "json"
    },

    createContent: function () {
      return new HTML({
        sanitizeContent: false,
        content: `
          <iframe
            src="./index.html"
            style="border:none;width:100%;height:100vh">
          </iframe>
        `
      });
    }
  });
});
